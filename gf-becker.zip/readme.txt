GF Fonts - Free Truetype fonts!

        You may not distribute, sell, resell, change or modify the fonts -but 
        you are allowed to upload the fonts onto a free font site if this disclaimer 
        is included in the download (readme.txt). Any other means prohibited.
        Commercial or corporate use of the free fonts prohibited. For commercial 
        or corporate use or publishing on e.g. CD ROM please contact gf@goldnagl.at
        For more information, see our site at  http://www.goldnagl.at